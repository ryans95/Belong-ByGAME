	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
				<li><a href="manage-bookings.php"><i class="fa fa-users"></i> Manage Booking</a></li>
				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop""></i> Manage Contact us Query</a></li>
				<li><a href="reg-users.php"><i class="fa fa-users"></i> Register Users</a></li>
				<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li>
				<li><a href="manage-subscribers.php"><i class="fa fa-table"></i> Manage Subscribers</a></li>
			</ul>
		</nav>